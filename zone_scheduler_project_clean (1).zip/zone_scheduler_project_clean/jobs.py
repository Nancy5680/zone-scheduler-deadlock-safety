"""Shared job definitions and deterministic scheduling helpers."""
from dataclasses import dataclass
from typing import List, Tuple

@dataclass(frozen=True)
class Job:
    name: str
    arrival: int
    burst: int
    priority: int
    zone: str

JOBS = [
    Job("J1", 0, 5, 2, "A"),
    Job("J2", 1, 3, 1, "B"),
    Job("J3", 2, 4, 3, "A"),
    Job("J4", 4, 2, 2, "C"),
]

def fcfs(jobs: List[Job]) -> List[Tuple[str, int, int]]:
    t = 0; out = []
    for j in sorted(jobs, key=lambda x: (x.arrival, x.name)):
        t = max(t, j.arrival); start = t; t += j.burst
        out.append((j.name, start, t))
    return out

if __name__ == "__main__":
    for row in fcfs(JOBS):
        print(f"{row[0]}: {row[1]} -> {row[2]}")
