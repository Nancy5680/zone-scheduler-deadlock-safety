# Zone Scheduler — Deadlock Safety

A small, reproducible Python project demonstrating scheduling, synchronization, deadlock detection/prevention, and memory/resource safety, followed by an architecture blueprint for Tasks 9–14.

## Requirements
- Python 3.8+
- Standard library only

## Run
From the repository root:

```bash
python jobs.py
python scripts/run_all.py
```

Individual demonstrations:

```bash
python scripts/01_scheduling.py
python scripts/02_synchronization.py
python scripts/03_deadlock_detection.py
python scripts/04_memory_safety.py
python scripts/05_zone_scheduler.py
```

## Repository layout

```text
.
├── jobs.py
├── README.md
├── docs/
│   └── architecture_blueprint.md
└── scripts/
    ├── 01_scheduling.py
    ├── 02_synchronization.py
    ├── 03_deadlock_detection.py
    ├── 04_memory_safety.py
    ├── 05_zone_scheduler.py
    └── run_all.py
```

The examples use deterministic inputs and standard-library synchronization primitives so the demonstrations are easy to reproduce.
