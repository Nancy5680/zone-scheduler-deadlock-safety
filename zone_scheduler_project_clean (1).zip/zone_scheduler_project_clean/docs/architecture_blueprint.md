# Part 2 — Architecture Blueprint (Tasks 9–14)

## Task 9 — System architecture
A layered design is used: **API/CLI → Scheduler Service → Safety Engine → Resource/Zone Manager → Persistence/Observability**. The scheduler accepts jobs, the safety engine validates resource requests and lock ordering, and the zone manager owns per-zone synchronization.

## Task 10 — Scheduling flow
1. Validate a job request.
2. Place the job in the ready queue.
3. Select the next job using the configured policy.
4. Check memory/resource safety.
5. Acquire required zone locks in a globally consistent order.
6. Execute the job.
7. Release resources and record metrics.

## Task 11 — Deadlock prevention
Deadlocks are prevented rather than merely detected. All multi-resource operations acquire resources in a single canonical order. Lock scope is kept small, locks are released with structured context managers, and timeouts can be used as a final safety boundary.

## Task 12 — Memory and resource safety
Each job declares a bounded resource request. The Safety Engine rejects requests that exceed configured capacity and records the reason. Admission control occurs before locks are acquired, reducing the chance of holding locks while waiting for resources.

## Task 13 — Failure handling and observability
Every job has a state (`QUEUED`, `RUNNING`, `COMPLETED`, `REJECTED`, or `FAILED`). Structured logs capture job ID, zone, state transition, duration, and rejection reason. Metrics should include queue depth, throughput, latency, rejected jobs, and lock-wait time.

## Task 14 — Scalability and deployment
The service can be deployed behind an API gateway with stateless scheduler workers. A durable queue separates ingestion from execution. Zone ownership can be partitioned so independent zones scale horizontally. Health checks, graceful shutdown, bounded queues, and idempotent job IDs provide operational safety.

### Component view
```text
Client
  |
  v
API / CLI
  |
  v
Scheduler Service -----> Metrics / Logs
  |
  +----> Ready Queue
  |
  v
Safety Engine
  |  +-- admission / memory checks
  |  +-- deadlock prevention
  v
Zone Manager
  |
  +--> Zone A lock/resource
  +--> Zone B lock/resource
  +--> Zone C lock/resource
  |
  v
Job Executor
```
