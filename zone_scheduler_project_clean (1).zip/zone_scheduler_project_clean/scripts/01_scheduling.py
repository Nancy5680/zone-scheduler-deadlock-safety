"""Part 1 - deterministic FCFS scheduling demonstration."""
from jobs import JOBS, fcfs

print("=== Scheduling: FCFS ===")
print("Job  Arrival  Burst  Priority  Zone")
for j in JOBS:
    print(f"{j.name:<4} {j.arrival:>7} {j.burst:>6} {j.priority:>8}  {j.zone}")
print("\nTimeline")
for name, start, end in fcfs(JOBS):
    print(f"{name}: [{start}, {end})")
