"""Part 1 - memory/safety checks for scheduled jobs."""
from jobs import JOBS

MEMORY_LIMIT = 12
used = 0
print("=== Memory safety ===")
for job in JOBS:
    request = job.burst
    status = "ALLOW" if used + request <= MEMORY_LIMIT else "DENY"
    if status == "ALLOW": used += request
    print(f"{job.name}: request={request:>2} used={used:>2}/{MEMORY_LIMIT} -> {status}")
print(f"Final usage: {used}/{MEMORY_LIMIT}")
