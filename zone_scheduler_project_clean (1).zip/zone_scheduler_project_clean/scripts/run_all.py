"""Run all Part 1 demonstrations in a predictable order."""
import runpy
from pathlib import Path
ROOT = Path(__file__).resolve().parent
for name in ["01_scheduling.py", "02_synchronization.py", "03_deadlock_detection.py", "04_memory_safety.py", "05_zone_scheduler.py"]:
    print("\n" + "#" * 60)
    runpy.run_path(str(ROOT / name), run_name="__main__")
