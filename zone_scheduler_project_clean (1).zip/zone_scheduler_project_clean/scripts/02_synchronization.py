"""Part 1 - synchronization using a lock and deterministic shared state."""
import threading

counter = 0
lock = threading.Lock()

def worker(iterations: int):
    global counter
    for _ in range(iterations):
        with lock:
            counter += 1

threads = [threading.Thread(target=worker, args=(1000,)) for _ in range(4)]
for t in threads: t.start()
for t in threads: t.join()

print("=== Synchronization ===")
print(f"Workers: {len(threads)}")
print("Iterations/worker: 1000")
print(f"Protected counter: {counter}")
