"""Integrated zone scheduler with per-zone locks and deadlock-safe ordering."""
from jobs import JOBS
from threading import Lock

zones = {z: Lock() for z in sorted({j.zone for j in JOBS})}
print("=== Zone scheduler / deadlock safety ===")
for j in sorted(JOBS, key=lambda x: (x.arrival, x.name)):
    # Always acquire zone locks in global sorted order; each job uses one zone here.
    with zones[j.zone]:
        print(f"scheduled {j.name} in zone {j.zone} for {j.burst} ticks")
print("Result: completed without lock-order deadlock")
