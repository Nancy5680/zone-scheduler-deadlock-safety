"""Part 1 - wait-for graph deadlock detection."""

def has_cycle(graph):
    visiting, done = set(), set()
    def dfs(node):
        if node in visiting: return True
        if node in done: return False
        visiting.add(node)
        for nxt in graph.get(node, []):
            if dfs(nxt): return True
        visiting.remove(node); done.add(node)
        return False
    return any(dfs(n) for n in graph)

safe = {"T1": ["T2"], "T2": []}
deadlocked = {"T1": ["T2"], "T2": ["T3"], "T3": ["T1"]}
print("=== Deadlock detection ===")
print(f"Safe graph: {'DEADLOCK' if has_cycle(safe) else 'NO DEADLOCK'}")
print(f"Cyclic graph: {'DEADLOCK' if has_cycle(deadlocked) else 'NO DEADLOCK'}")
